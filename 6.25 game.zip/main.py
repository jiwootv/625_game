"""
1950 : 정지
메인 코드 파일
"""
BLACK = (0, 0, 0)
import pygame
import os
import sys

width = 640  # 가로 길이 설정
height = 480  # 세로 길이 설정
fps = 30
game_name = "625"
speed = 10

WHITE = (255, 255, 255)


class Save:
    def __init__(self):
        self.file0 = open(r"data\save\file0", "r", encoding="cp949")
        self.file0_r = self.file0.readlines()
        print(self.file0_r)
        self.file0.close()
        self.file0 = open(r"data\save\file0", "w", encoding="cp949")

    def edit(self, line, r):
        self.file0_r[line] = str(r) + "\n"

    def write(self):
        for i in self.file0_r:
            print(i)
            self.file0.write(str(i))
        self.file0.close()


S = Save()


class Game:
    def __init__(self):
        # 메인 셋팅
        self.fullscreen = False
        pygame.init()
        pygame.mixer.init()
        pygame.display.set_caption(game_name)
        self.screen = pygame.display.set_mode((width, height))  # 창 설정
        self.clock = pygame.time.Clock()  # 시간 설정

        # 플레이어 설정
        self.p = pygame.image.load("data/img/군인 초기Model_정면.png")
        self.p.set_colorkey((255, 255, 255))  # 플레이어 하양색 삭제
        self.p_pos = [160, 260]  # 좌표
        self.movement = [True, False]
        self.font = pygame.font.SysFont("malgungothic", 50)
        # 음악 설정
        self.IntroBgm = pygame.mixer.Sound(r"data\sound\mus_IntroBGM.ogg")
        self.text = lambda x, y: pygame.font.SysFont("malgungothic", x).render(y, 1, BLACK)

    def title(self):
        self.IntroBgm.play(-1)
        self.IntroBgm.set_volume(5)
        BLACK = (0, 0, 0)
        WHITE = (255, 255, 255)
        font = pygame.font.SysFont("malgungothic", 50)
        text1 = font.render("1950 : 정지", 1, WHITE)
        text2 = font.render("By YJ, Capkss", 1, WHITE)
        title_lines = [text1, text2]
        title_pos = [[180, 190], [180, 190]]

        title_delay = 7000  # Milliseconds between title advances
        title_count = 4  # How many titles are in the animation
        title_index = 0  # what is the currently displayed title
        title_next_time = title_delay  # clock starts at 0, time for first title
        skip = 0
        while True:

            clock = pygame.time.get_ticks()  # time now

            self.pressed_key = pygame.key.get_pressed()
            # Handle events
            self.event()
            if self.pressed_key[pygame.K_z]:
                skip = 1

            # paint the screen
            self.screen.fill(BLACK)  # paint it black

            # Write the current title, unless we've seen them all
            if (title_index < title_count):
                self.screen.blit(title_lines[title_index], (title_pos[title_index][0], title_pos[title_index][1]))
            # Is it time to update to the next title?
            if (clock > title_next_time):
                title_next_time = clock + title_delay  # some seconds in the future
                title_index += 1  # advance to next title-image
                print(title_index)
            if title_index == 2 or skip == 1:
                break

            pygame.display.flip()
    def menu(self): pass

    def event(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:  # 게임 종료
                S.write()
                pygame.quit()
                sys.exit()
            # if event.type == pygame.KEYDOWN:  # 키 감지
            #     print("asd")
            #     if event.type == pygame.K_DOWN:
            #         print("w")
            #     if event.type == pygame.K_a:
            #         print("a")
            #     if event.type == pygame.K_s:
            #         self.screen.fill((255, 255, 10))
            #     if event.type == pygame.K_d:
            #         print("d")
    def run(self):
        self.title()
        while True:  # 게임 반복 루트
            self.screen.fill((255, 255, 255))
            self.pressed_key = pygame.key.get_pressed()
            self.screen.blit(self.text(50, "You aren't gay!"),(0, 0))
            # Player blit
            self.screen.blit(self.p, (self.p_pos[0], self.p_pos[1]))
            self.event()

            pygame.display.update()
            self.clock.tick(60)


Game().run()
