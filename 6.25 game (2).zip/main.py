"""
1950 : 정지
메인 코드 파일
"""

BLACK = (0, 0, 0)
import pygame
import sys
import data.img.map as M
import data.code.save

width = 640  # 가로 길이 설정
height = 480  # 세로 길이 설정
fps = 30
game_name = "625"
speed = 10

WHITE = (255, 255, 255)


class Save:
    def __init__(self):
        self.file0 = open(r"data\save\file0", "r", encoding="cp949")
        self.file0_r = self.file0.readlines()
        print(self.file0_r)
        self.file0.close()
        self.file0 = open(r"data\save\file0", "w", encoding="cp949")

    def edit(self, line, r):
        self.file0_r[line] = str(r) + "\n"

    def write(self):
        for i in self.file0_r:
            print(i)
            self.file0.write(str(i))
        self.file0.close()


# noinspection PyUnresolvedReferences
S = data.code.save.Save()


class Selsect_cousor:
    def __init__(self, screen, cousor_type=1):
        self.s = screen
        self.cousor_sprite = []
        self.c_img = pygame.image.load(r"data\img\cousor\cousor1.png")
        self.c_img = pygame.transform.scale(self.c_img, (117.5, 25))

        print(self.c_img.get_size())

    def cousor_show(self):
        self.s.blit(self.c_img, (0, 0))


class Game:

    def __init__(self):
        # 메인 셋팅
        self.fullscreen = False
        pygame.init()
        pygame.mixer.init()
        pygame.display.set_caption(game_name)
        self.screen = pygame.display.set_mode((width, height))  # 창 설정
        # DISPLAYSURF = pygame.display.set_mode((400, 300), FULLSCREEN)
        self.clock = pygame.time.Clock()  # 시간 설정

        self.menunext = 0
        self.KDOWN = False

        self.CO = Selsect_cousor(self.screen)
        self.reload = False
        self.z_key = False

        # 플레이어 설정
        self.mapfile = M.Map()
        self.p = self.mapfile.assets["일반벽돌_회색"]
        self.p.set_colorkey((255, 255, 255))  # 플레이어 하양색 삭제
        self.p_pos = [160, 260]  # 좌표
        self.movement = [True, False]
        self.font = pygame.font.SysFont("malgungothic", 50)

        # 음악 설정
        self.IntroBgm = pygame.mixer.Sound(r"data\sound\mus_IntroBGM.ogg")
        self.text = lambda x, y: pygame.font.SysFont("malgungothic", x).render(y, 1, WHITE)
        pygame.mouse.set_visible(False)

    def title(self):

        self.IntroBgm.play(-1)
        self.IntroBgm.set_volume(5)

        BLACK = (0, 0, 0)
        WHITE = (255, 255, 255)
        font = pygame.font.SysFont("malgungothic", 50)
        text1 = font.render("", 1, WHITE)
        text2 = font.render("By YJ, Capkss", 1, WHITE)
        title_lines = [text1, text2]
        title_pos = [[180, 190], [180, 190]]

        title_delay = 2000  # Milliseconds between title advances
        title_count = 4  # How many titles are in the animation
        title_index = 0  # what is the currently displayed title
        title_next_time = title_delay  # clock starts at 0, time for first title
        skip = 0
        while True:
            self.CO.cousor_show()
            pygame.display.flip()
            clock = pygame.time.get_ticks()  # time now

            self.pressed_key = pygame.key.get_pressed()
            # Handle events
            self.event()
            if self.pressed_key[pygame.K_z]:
                skip = 1
                print("skip")

            # paint the screen
            self.screen.fill(BLACK)  # paint it black

            # Write the current title, unless we've seen them all
            if (title_index < title_count):
                self.screen.blit(title_lines[title_index], (title_pos[title_index][0], title_pos[title_index][1]))
            # Is it time to update to the next title?
            if (clock > title_next_time):
                title_next_time = clock + title_delay  # some seconds in the future
                title_index += 1  # advance to next title-image
                print(title_index)

            if title_index == 1 and clock > 6000: title_index += 1

            if title_index == 2 or skip == 1:
                print("break")
                break

    def menu(self):
        font = pygame.font.SysFont("malgungothic", 25)
        t = pygame.time.get_ticks()
        print("M")
        print(t)
        self.screen.fill(WHITE)
        while True:
            pygame.display.update()
            self.pressed_key = pygame.key.get_pressed()
            self.screen.fill(BLACK)
            self.screen.blit(self.text(50, "1 9 5 0: 정지"), (0, 0))
            self.screen.blit(self.text(20, "Press Z key to start"), (240, 120))
            self.event()
            if self.pressed_key[pygame.K_z] and pygame.time.get_ticks() > t + 3000:
                print(pygame.time.get_ticks(), t + 3000)
                break
        # 파트 2 - 세이브 데이터 설정
        w = width - width / 1.15
        h = height - height / 1.2
        w1 = width - width / 1.17
        h1 = height - height / 1.23
        s1_size = (480, 100)

        save1_rect = pygame.Rect(w, h, s1_size[0], s1_size[1])
        save1_rect_second = pygame.Rect(w1, h1, s1_size[0] - 20, s1_size[1] - 20)
        while True:
            # self.screen.fill((200, 100, 200))
            self.screen.fill(BLACK)
            self.screen.blit(self.text(30, "플레이할 파일을 선택하세요."), (0, 0))

            # File1 칸 드로우
            pygame.draw.rect(self.screen, WHITE, save1_rect)  # 메뉴 사각형 각각 3개중 하나생성
            pygame.draw.rect(self.screen, BLACK, save1_rect_second)  # 메뉴 사각형 각각 3개중 하나생성
            self.screen.blit(self.text(20, "파일 1"), (w + 15, h + 10))
            self.screen.blit(self.text(20, "내용 없음"), (w + 15, h + 40))
            # File2 칸 드로우
            pygame.draw.rect(self.screen, WHITE, pygame.Rect(w, h + 130, s1_size[0], s1_size[1]))  # 메뉴 사각형 각각 3개중 하나생성
            pygame.draw.rect(self.screen, BLACK,
                             pygame.Rect(w1, h1 + 130, s1_size[0] - 20, s1_size[1] - 20))  # 메뉴 사각형 각각 3개중 하나생성
            self.screen.blit(self.text(20, "파일 2"), (w + 15, h + 140))
            self.screen.blit(self.text(20, "내용 없음"), (w + 15, h + 170))

            # File3 칸 드로우
            pygame.draw.rect(self.screen, WHITE, pygame.Rect(w, h + 260, s1_size[0], s1_size[1]))  # 메뉴 사각형 각각 3개중 하나생성
            pygame.draw.rect(self.screen, BLACK,
                             pygame.Rect(w1, h1 + 260, s1_size[0] - 20, s1_size[1] - 20))  # 메뉴 사각형 각각 3개중 하나생성
            self.screen.blit(self.text(20, "파일 3"), (w + 15, h + 270))
            self.screen.blit(self.text(20, "내용 없음"), (w + 15, h + 300))

            # 디스플레이 업데이트, 이벤트 설정
            self.event()
            pygame.display.update()

    def event(self):
        self.pressed_key = pygame.key.get_pressed()  # 키 인식
        for event in pygame.event.get():
            if event.type == pygame.QUIT or self.pressed_key[pygame.K_ESCAPE]:  # 게임 종료
                S.write()
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                self.KDOWN = True
                if event.key == pygame.K_z:
                    self.z_key = True
                else:
                    self.z_key = False
            if event.type == pygame.KEYUP:
                self.KDOWN = False
                print("GAY")

            if self.pressed_key[pygame.K_z]:  # 만약 Z키를 눌렀는가?
                self.z_key = True
            if self.pressed_key[pygame.K_w]:  # W키를 눌렀는가
                pass

    def run(self):  # 쌈1뽕한 매인
        print("Game Run successfully")
        self.title()
        self.menu()
        print(" MAINRUN ")
        while True:  # 게임 반복 루트
            self.screen.fill((255, 255, 255))
            self.pressed_key = pygame.key.get_pressed()
            self.screen.blit(self.text(50, "You aren't gay!"), (0, 0))
            # Player blit
            self.screen.blit(self.p, (self.p_pos[0], self.p_pos[1]))
            self.event()

            pygame.display.update()
            self.clock.tick(60)


Game().run()
