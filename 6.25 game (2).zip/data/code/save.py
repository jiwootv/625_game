# save code
class Save:
    def __init__(self):
        self.file0 = open(r"data\save\file0", "r", encoding="cp949")
        self.file0_r = self.file0.readlines()
        print(self.file0_r)
        self.file0.close()
        self.file0 = open(r"data\save\file0", "w", encoding="cp949")

    def edit(self, line, r):
        self.file0_r[line] = str(r) + "\n"

    def write(self):
        for i in self.file0_r:
            print(i)
            self.file0.write(str(i))
        self.file0.close()