# this is main source assets.
# Grappic asset or maps.
import pygame
class Map:
    def __init__(self):
        self.assets = {"일반벽돌_회색":pygame.image.load(r"data\img\Bricks1.png"),"PlayerNormalFront":pygame.image.load(r"data\img\군인 초기Model_정면.png")}


if __name__ == "__main__":
    a = lambda x: x+10
    print(list(map(a, [100, 200, 300])))